External type annotations for legacy Thrift.
