namespace hack test.fixtures.oldenum

enum MyEnum {
  MyValue1 = 0,
  MyValue2 = 1,
}
