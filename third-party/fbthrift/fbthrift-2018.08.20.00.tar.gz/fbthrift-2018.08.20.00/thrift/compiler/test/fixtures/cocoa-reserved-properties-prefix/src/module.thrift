namespace cocoa example

struct Example {
  1: required string name;
  2: required string description (cocoa.name = "xyz_description");
}
