namespace cpp2 test_cpp2.cpp_reflection

struct dep_B_struct {
  1: i32 i_b
}
