namespace java.swift test.fixtures.empty_struct

struct Empty {
}

union Nada {
}
