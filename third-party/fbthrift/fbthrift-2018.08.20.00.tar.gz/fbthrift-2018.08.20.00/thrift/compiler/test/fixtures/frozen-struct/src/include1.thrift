namespace cpp2 some.ns

struct IncludedA {
  1: i32 i32Field,
  2: string strField
}
