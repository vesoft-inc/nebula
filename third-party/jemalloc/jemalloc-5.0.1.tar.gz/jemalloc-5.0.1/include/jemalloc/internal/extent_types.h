#ifndef JEMALLOC_INTERNAL_EXTENT_TYPES_H
#define JEMALLOC_INTERNAL_EXTENT_TYPES_H

typedef struct extent_s extent_t;
typedef struct extents_s extents_t;

#define EXTENT_HOOKS_INITIALIZER	NULL

#endif /* JEMALLOC_INTERNAL_EXTENT_TYPES_H */
