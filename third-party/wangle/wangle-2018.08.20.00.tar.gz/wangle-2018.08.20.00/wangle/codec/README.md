Codecs are modeled after netty's codecs:

https://github.com/netty/netty/tree/master/codec/src/main/java/io/netty/handler/codec

Most of the changes are due to differing memory allocation strategies.
