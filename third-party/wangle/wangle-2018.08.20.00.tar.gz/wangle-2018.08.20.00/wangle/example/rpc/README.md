# RPC client/server example
---------------------------

Similar to the telnet example, this provides examples of using a
Pipeline and Server/Client bootstrap libraries.  In addition, it
provides examples of:

* Custom codec for serialization
* Service interface, to match up requests with replies.  Various
  versions of this are in the comments
* ServiceFilters, for timeouts, logging, etc.
