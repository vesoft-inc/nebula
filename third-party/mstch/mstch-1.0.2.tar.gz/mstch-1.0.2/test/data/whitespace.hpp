const auto whitespace_data = mstch::map{
  {"tag1", std::string{"Hello"}},
  {"tag2", std::string{"World"}}
};