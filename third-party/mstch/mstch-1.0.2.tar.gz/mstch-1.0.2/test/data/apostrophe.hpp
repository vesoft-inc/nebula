const auto apostrophe_data = mstch::map{
  {"apos", std::string{"'"}},
  {"control", std::string{"X"}}
};