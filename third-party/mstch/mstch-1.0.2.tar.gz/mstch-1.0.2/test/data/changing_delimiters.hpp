const mstch::node changing_delimiters_data = mstch::map{
  {"foo", std::string{"foooooooooooooo"}},
  {"bar", std::string{"<b>bar!</b>"}}
};
