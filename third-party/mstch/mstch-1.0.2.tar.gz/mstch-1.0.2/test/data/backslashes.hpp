const auto backslashes_data = mstch::map{
  {"value", std::string{"\\abc"}}
};