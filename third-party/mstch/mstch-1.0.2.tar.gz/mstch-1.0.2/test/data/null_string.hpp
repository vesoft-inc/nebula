const auto null_string_data = mstch::map{
  {"name", std::string{"Elise"}},
  {"glytch", true},
  {"binary", false},
  {"value", mstch::node{}}
};
