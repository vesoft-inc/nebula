const auto included_tag_data = mstch::map{
  {"html", std::string{"I like {{mustache}}"}}
};