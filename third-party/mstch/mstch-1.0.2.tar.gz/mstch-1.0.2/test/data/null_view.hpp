const auto null_view_data = mstch::map{
  {"name", std::string{"Joe"}},
  {"friends", mstch::node{}}
};