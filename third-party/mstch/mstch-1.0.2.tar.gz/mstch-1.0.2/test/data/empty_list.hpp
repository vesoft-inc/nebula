const auto empty_list_data = mstch::map{
  {"jobs", mstch::array{}}
};