const auto two_in_a_row_data = mstch::map{
  {"name", std::string{"Joe"}},
  {"greeting", std::string{"Welcome"}}
};