const auto partial_array_of_partials_implicit_data = mstch::map{
  {"numbers", mstch::array{std::string{"1"}, std::string{"2"}, std::string{"3"}, std::string{"4"}}}
};