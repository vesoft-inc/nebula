const auto keys_with_questionmarks_data = mstch::map{
  {"person?", mstch::map{
    {"name", std::string{"Jon"}}
  }}
};