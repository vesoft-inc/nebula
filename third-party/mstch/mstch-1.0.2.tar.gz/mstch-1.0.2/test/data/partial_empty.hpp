const auto partial_empty_data = mstch::map{
  {"foo", 1}
};