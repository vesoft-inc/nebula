const mstch::node delimiters_data = mstch::map{
  {"first", std::string{"It worked the first time."}},
  {"second", std::string{"And it worked the second time."}},
  {"third", std::string{"Then, surprisingly, it worked the third time."}},
  {"fourth", std::string{"Fourth time also fine!."}}
};
