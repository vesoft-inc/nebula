const auto bug_11_eating_whitespace_data = mstch::map{
  {"tag", std::string{"yo"}}
};