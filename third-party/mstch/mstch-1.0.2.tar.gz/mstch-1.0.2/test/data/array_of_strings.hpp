const auto array_of_strings_data = mstch::map{
  {"array_of_strings", mstch::array{std::string{"hello"}, std::string{"world"}}}
};