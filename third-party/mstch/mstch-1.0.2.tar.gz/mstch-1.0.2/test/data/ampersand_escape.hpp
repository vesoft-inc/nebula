const auto ampersand_escape_data = mstch::map{
  {"message", std::string{"Some <code>"}}
};