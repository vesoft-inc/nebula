const auto bug_length_property_data = mstch::map{
    {"length", std::string{"hello"}}
};