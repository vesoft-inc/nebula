const auto implicit_iterator_data = mstch::map{
  {"data", mstch::map{
    {"author", mstch::map{
      {"twitter_id", 819606},
      {"name", std::string{"janl"}}
    }}
  }}
};
