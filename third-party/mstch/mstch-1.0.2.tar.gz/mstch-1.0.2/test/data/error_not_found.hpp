const auto error_not_found_data = mstch::map{
  {"bar", 2}
};