const auto disappearing_whitespace_data = mstch::map{
  {"bedrooms", true},
  {"total", 1}
};