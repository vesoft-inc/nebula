const auto error_eof_in_section_data = mstch::map{
    {"hello", mstch::array{std::string{"a"}, std::string{"b"}}}
};